package com.example.midtermexam

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ThirdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.third_activity)

        val textViewPassedText : TextView = findViewById(R.id.textViewPassedAgain)
        val buttonGit : Button = findViewById(R.id.buttonGoToGitHub)

        // Get the passed email from Intent
        val plainText = intent.getStringExtra("passed_string")

        textViewPassedText.text = plainText

        buttonGit.setOnClickListener {
            val GitHubLink = "https://github.com/vannicc"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(GitHubLink))
            startActivity(intent)
        }
    }

    public override fun onStart() {
        super.onStart()
        Log.v("Third Activity", "activity 3 has started")
    }

    public override fun onResume() {
        super.onResume()
        Log.v("Third Activity", "activity 3 has resumed")
    }

    public override fun onPause() {
        super.onPause()
        Log.v("Third Activity", "activity 3 has paused")
    }

    public override fun onStop() {
        super.onStop()
        Log.v("Third Activity", "activity 3 has stopped")
    }

    public override fun onDestroy() {
        super.onDestroy()
        Log.v("Third Activity", "activity 3 has stopped")
    }
}