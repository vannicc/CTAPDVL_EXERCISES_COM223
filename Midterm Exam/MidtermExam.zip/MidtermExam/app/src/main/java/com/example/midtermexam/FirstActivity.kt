package com.example.midtermexam

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class FirstActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.first_activity)

        val buttonNext : Button = findViewById(R.id.button)
        val editText : EditText = findViewById(R.id.editTextText)

        buttonNext.setOnClickListener {
            val text = editText.text.toString()
            val intent = Intent(this, SecondActivity::class.java)
            intent.putExtra("pass_string", text)
            startActivity(intent)
        }
    }

    public override fun onStart() {
        super.onStart()
        Log.v("First Activity", "activity 1 has started")
    }

    public override fun onResume() {
        super.onResume()
        Log.v("First Activity", "activity 1 has resumed")
    }

    public override fun onPause() {
        super.onPause()
        Log.v("First Activity", "activity 1 has paused")
    }

    public override fun onStop() {
        super.onStop()
        Log.v("First Activity", "activity 1 has stopped")
    }

    public override fun onDestroy() {
        super.onDestroy()
        Log.v("First Activity", "activity 1 has stopped")
    }
}