package com.example.midtermexam

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.second_activity)

        val textViewPassedText : TextView = findViewById(R.id.textViewPassedText)
        val buttonNext : Button = findViewById(R.id.button2)

        // Get the passed email from Intent
        val plainText = intent.getStringExtra("pass_string")

        textViewPassedText.text = plainText

        buttonNext.setOnClickListener{
            val text = plainText.toString()
            val intent = Intent(this, ThirdActivity::class.java)
            intent.putExtra("passed_string", text)
            startActivity(intent)
        }
    }

    public override fun onStart() {
        super.onStart()
        Log.v("Second Activity", "activity 2 has started")
    }

    public override fun onResume() {
        super.onResume()
        Log.v("Second Activity", "activity 2 has resumed")
    }

    public override fun onPause() {
        super.onPause()
        Log.v("Second Activity", "activity 2 has paused")
    }

    public override fun onStop() {
        super.onStop()
        Log.v("Second Activity", "activity 2 has stopped")
    }

    public override fun onDestroy() {
        super.onDestroy()
        Log.v("Second Activity", "activity 2 has stopped")
    }
}