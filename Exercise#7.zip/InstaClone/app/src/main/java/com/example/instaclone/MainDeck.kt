package com.example.instaclone

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainDeck : AppCompatActivity() {

    // Reference to fragments
    private lateinit var homeFragment: HomeFragment
    private lateinit var profileFragment: ProfileFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_deck)

        // Get the email from MainActivity
        val email = intent.getStringExtra("email_key")

        // Create fragments and pass data
        homeFragment = HomeFragment().apply {
            arguments = Bundle().apply {
                putString("email_key", email)
            }
        }

        profileFragment = ProfileFragment.newInstance(email ?: "")

        // Set initial fragment
        setFragment(homeFragment)

        // Set up bottom navigation
        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottomNavigationView)

        val searchFragment = SearchFragment()
        val addPostFragment = AddPostFragment()
        val notifFragment = NotifFragment()

        bottomNavigationView.setOnItemSelectedListener {
            when(it.itemId) {
                R.id.navHome -> setFragment(homeFragment)
                R.id.navProfile -> setFragment(profileFragment)
                R.id.navPost -> setFragment(addPostFragment)
                R.id.navNotif -> setFragment(notifFragment)
                R.id.navSearch -> setFragment(searchFragment)
            }
            true
        }
    }

    private fun setFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.flFragment, fragment)
            commit()
        }
    }

    // Forward activity results to the currently active fragment
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Get the current fragment
        val currentFragment = supportFragmentManager.findFragmentById(R.id.flFragment)

        // Forward the result to the fragment
        currentFragment?.onActivityResult(requestCode, resultCode, data)
    }
}