package com.example.instaclone

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.instaclone.R

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Find the TextViews
        val textViewUsername: TextView = findViewById(R.id.textViewUsername)
        val textViewPostUsername: TextView = findViewById(R.id.textViewPostUsername)
        val imageViewMyProfile: ImageView = findViewById(R.id.imageViewMyProfile)

        // Get the passed email from Intent
        val email = intent.getStringExtra("email_key")

        // Set the email to the TextViews
        textViewUsername.text = email
        textViewPostUsername.text = email

        // Set click listener to imageViewMyProfile
        imageViewMyProfile.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            intent.putExtra("logged_user_email", email)
            startActivity(intent)
        }
    }
}
