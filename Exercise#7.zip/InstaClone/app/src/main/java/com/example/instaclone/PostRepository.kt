// PostRepository.kt
package com.example.instaclone

object PostRepository {
    fun getPosts(): List<Post> {
        return PresidentId.values().map { presidentId ->
            Post(
                presidentId = presidentId,
                presidentName = FakeRepository.presidentName[presidentId] ?: "",
                presidentTitle = FakeRepository.presidentOrder[presidentId] ?: "",
                portraitResId = FakeRepository.portrait[presidentId] ?: R.drawable.user_profile
            )
        }
    }
}