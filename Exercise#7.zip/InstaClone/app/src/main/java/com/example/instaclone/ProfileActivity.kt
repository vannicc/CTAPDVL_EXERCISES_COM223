package com.example.instaclone

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    private lateinit var imageViewAddPost: ImageView
    private lateinit var imageViewAddPostNow: ImageView
    private lateinit var imageViewPosts: ImageView
    private lateinit var textViewEditProfile: TextView
    private lateinit var imageViewUserProfile: ImageView

    // Request codes for image selection
    private val PICK_POST_IMAGE_REQUEST = 1
    private val PICK_PROFILE_IMAGE_REQUEST = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val textViewLoggedUser: TextView = findViewById(R.id.textViewLoggedUser)

        // Get the passed email from Intent
        val loggedUserEmail = intent.getStringExtra("logged_user_email")

        // Set it to textViewLoggedUser
        textViewLoggedUser.text = loggedUserEmail

        val imageViewHome: ImageView = findViewById(R.id.imageViewHome)

        // Set click listener for imageViewHome
        imageViewHome.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.putExtra("email_key", loggedUserEmail)
            startActivity(intent)
            finish() // optional, if you want to prevent going back to ProfileActivity when pressing back button
        }

        // Initialize views
        imageViewAddPost = findViewById(R.id.imageViewAddPost)
        imageViewAddPostNow = findViewById(R.id.imageViewAddPostNow)
        imageViewPosts = findViewById(R.id.imageViewPosts)
        textViewEditProfile = findViewById(R.id.textViewEditProfile)
        imageViewUserProfile = findViewById(R.id.imageViewUserProfile)

        // Set click listener for imageViewAddPost
        imageViewAddPost.setOnClickListener {
            openGalleryForPost()
        }

        // Set click listener for imageViewAddPostNow
        imageViewAddPostNow.setOnClickListener {
            openGalleryForPost()
        }

        // Set click listener for textViewEditProfile to change profile picture
        textViewEditProfile.setOnClickListener {
            openGalleryForProfile()
        }
    }

    // Function to open the gallery for post image
    private fun openGalleryForPost() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(intent, PICK_POST_IMAGE_REQUEST)
    }

    // Function to open the gallery for profile image
    private fun openGalleryForProfile() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(intent, PICK_PROFILE_IMAGE_REQUEST)
    }

    // Handle the result of the image selection
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            val imageUri: Uri = data.data!!

            when (requestCode) {
                PICK_PROFILE_IMAGE_REQUEST -> {
                    // Update imageViewUserProfile with the selected image
                    imageViewUserProfile.setImageURI(imageUri)
                }
                PICK_POST_IMAGE_REQUEST -> {
                    // Update imageViewPosts with the selected image
                    imageViewPosts.setImageURI(imageUri)
                }
            }
        }
    }
}
