package com.example.instaclone

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialException
import androidx.lifecycle.lifecycleScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var credentialManager: CredentialManager
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()

        // Initialize Realtime Database
        database = FirebaseDatabase.getInstance().reference

        // Initialize Credential Manager
        credentialManager = CredentialManager.create(this)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val loginButton: Button = findViewById(R.id.buttonLogIn)
        val editEmail: EditText = findViewById(R.id.editEmail)
        val editPassword: EditText = findViewById(R.id.editPassword)
        val googleSignInButton: ImageView = findViewById(R.id.imageViewGoogleIcon)

        // Regular email/password login
        loginButton.setOnClickListener {
            val email = editEmail.text.toString()
            val password = editPassword.text.toString()

            // First, check if fields are empty
            if (email.isEmpty()) {
                editEmail.error = "Email is required"
                editEmail.requestFocus()
                return@setOnClickListener
            }

            if (password.isEmpty()) {
                editPassword.error = "Password is required"
                editPassword.requestFocus()
                return@setOnClickListener
            }

            // Sign in with Realtime Database
            signInWithDatabase(email, password)
        }

        // Google Sign-In
        googleSignInButton.setOnClickListener {
            signInWithGoogle()
        }
    }

    private fun signInWithDatabase(email: String, password: String) {
        // Query the database for user with matching email
        database.child("users").orderByChild("email").equalTo(email)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        // User found, check password
                        for (userSnapshot in snapshot.children) {
                            val userPassword = userSnapshot.child("password").getValue(String::class.java)
                            if (userPassword == password) {
                                // Password matches, login successful
                                val userName = userSnapshot.child("name").getValue(String::class.java) ?: "User"
                                navigateToMainDeck(email)
                                return
                            }
                        }
                        // Password doesn't match
                        Toast.makeText(this@MainActivity, "Incorrect password", Toast.LENGTH_SHORT).show()
                    } else {
                        // User not found
                        Toast.makeText(this@MainActivity, "User not found", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("MainActivity", "Database error: ${error.message}")
                    Toast.makeText(this@MainActivity, "Login failed: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun signInWithEmailPassword(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    Log.d("MainActivity", "signInWithEmail:success")
                    val user = auth.currentUser
                    navigateToMainDeck(user?.email ?: email)
                } else {
                    Log.w("MainActivity", "signInWithEmail:failure", task.exception)
                    Toast.makeText(this, "Authentication failed: ${task.exception?.message}",
                        Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun signInWithGoogle() {
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false) // Set to false to show all accounts
            .setServerClientId(getString(R.string.default_web_client_id))
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        lifecycleScope.launch {
            try {
                val result = credentialManager.getCredential(
                    request = request,
                    context = this@MainActivity,
                )
                handleSignIn(result)
            } catch (e: GetCredentialException) {
                Log.e("MainActivity", "Google Sign-In failed", e)
                Toast.makeText(this@MainActivity, "Google Sign-In failed: ${e.message}",
                    Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun handleSignIn(result: GetCredentialResponse) {
        when (val credential = result.credential) {
            is GoogleIdTokenCredential -> {
                val googleIdToken = credential.idToken
                Log.d("MainActivity", "Received Google ID Token: $googleIdToken")

                // Sign in to Firebase with Google credential
                val firebaseCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                auth.signInWithCredential(firebaseCredential)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            Log.d("MainActivity", "signInWithCredential:success")
                            val user = auth.currentUser

                            // Store Google user in Realtime Database
                            storeGoogleUserInDatabase(user?.displayName, user?.email)

                            navigateToMainDeck(user?.email ?: "")
                        } else {
                            Log.w("MainActivity", "signInWithCredential:failure", task.exception)
                            Toast.makeText(this, "Firebase authentication failed: ${task.exception?.message}",
                                Toast.LENGTH_SHORT).show()
                        }
                    }
            }
            else -> {
                Log.e("MainActivity", "Unexpected type of credential")
                Toast.makeText(this, "Unexpected credential type", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun storeGoogleUserInDatabase(name: String?, email: String?) {
        if (email != null) {
            val userId = email.replace(".", "_") // Firebase keys can't contain periods
            val user = mapOf(
                "name" to (name ?: "Google User"),
                "email" to email,
                "loginMethod" to "google",
                "lastLogin" to System.currentTimeMillis()
            )

            database.child("users").child(userId).setValue(user)
                .addOnSuccessListener {
                    Log.d("MainActivity", "Google user stored in database")
                }
                .addOnFailureListener { e ->
                    Log.e("MainActivity", "Failed to store Google user: ${e.message}")
                }
        }
    }

    private fun navigateToMainDeck(email: String) {
        val intent = Intent(this, MainDeck::class.java)
        intent.putExtra("email_key", email)
        startActivity(intent)
        finish()
    }

    override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly
        val currentUser = auth.currentUser
        if (currentUser != null) {
            navigateToMainDeck(currentUser.email ?: "")
        }
    }
}