package com.example.instaclone

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialException
import androidx.lifecycle.lifecycleScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var credentialManager: CredentialManager
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()

        // Initialize Realtime Database
        database = FirebaseDatabase.getInstance().reference

        // Initialize Credential Manager
        credentialManager = CredentialManager.create(this)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val loginButton: Button = findViewById(R.id.buttonLogIn)
        val editEmail: EditText = findViewById(R.id.editEmail)
        val editPassword: EditText = findViewById(R.id.editPassword)
        val googleSignInButton: ImageView = findViewById(R.id.imageViewGoogleIcon)

        // Regular email/password login
        loginButton.setOnClickListener {
            val email = editEmail.text.toString()
            val password = editPassword.text.toString()

            // First, check if fields are empty
            if (email.isEmpty()) {
                editEmail.error = "Email is required"
                editEmail.requestFocus()
                return@setOnClickListener
            }

            if (password.isEmpty()) {
                editPassword.error = "Password is required"
                editPassword.requestFocus()
                return@setOnClickListener
            }

            // Sign in with Realtime Database
            signInWithDatabase(email, password)
        }

        // Google Sign-In
        googleSignInButton.setOnClickListener {
            signInWithGoogle()
        }
    }

    private fun signInWithDatabase(email: String, password: String) {
        // Query the database for user with matching email
        database.child("users").orderByChild("email").equalTo(email)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        // User found, check password
                        for (userSnapshot in snapshot.children) {
                            val userPassword = userSnapshot.child("password").getValue(String::class.java)
                            if (userPassword == password) {
                                // Password matches, login successful
                                val userName = userSnapshot.child("name").getValue(String::class.java) ?: "User"

                                // Toast confirmation for username retrieval
                                Toast.makeText(this@MainActivity, "Username retrieved: $userName", Toast.LENGTH_SHORT).show()

                                navigateToMainDeck(userName, email) // Pass both name and email
                                return
                            }
                        }
                        // Password doesn't match
                        Toast.makeText(this@MainActivity, "Incorrect password", Toast.LENGTH_SHORT).show()
                    } else {
                        // User not found
                        Toast.makeText(this@MainActivity, "User not found", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("MainActivity", "Database error: ${error.message}")
                    Toast.makeText(this@MainActivity, "Login failed: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun signInWithEmailPassword(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    Log.d("MainActivity", "signInWithEmail:success")
                    val user = auth.currentUser
                    // Need to get name from database for Firebase Auth users
                    getUserNameFromDatabase(user?.displayName ?: email)
                } else {
                    Log.w("MainActivity", "signInWithEmail:failure", task.exception)
                    Toast.makeText(this, "Authentication failed: ${task.exception?.message}",
                        Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun getUserNameFromDatabase(email: String) {
        if (email.isEmpty()) {
            Toast.makeText(this, "Error: Empty email provided", Toast.LENGTH_SHORT).show()
            Log.e("MainActivity", "getUserNameFromDatabase called with empty email")
            navigateToMainDeck("User", "unknown@email.com")
            return
        }

        Toast.makeText(this, "Searching database for: $email", Toast.LENGTH_SHORT).show()

        database.child("users").orderByChild("email").equalTo(email)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    var userName = "User" // Default name
                    if (snapshot.exists()) {
                        for (userSnapshot in snapshot.children) {
                            userName = userSnapshot.child("name").getValue(String::class.java) ?: "User"
                            break
                        }
                        // Toast confirmation for successful username retrieval
                        Toast.makeText(this@MainActivity, "Username found: $userName", Toast.LENGTH_SHORT).show()
                    } else {
                        // Toast for when no user is found in database
                        Toast.makeText(this@MainActivity, "No user found in database for: $email", Toast.LENGTH_SHORT).show()
                    }

                    Log.d("MainActivity", "Navigating to MainDeck with name: $userName, email: $email")
                    navigateToMainDeck(userName, email)
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("MainActivity", "Database error: ${error.message}")
                    // Toast for database error
                    Toast.makeText(this@MainActivity, "Database error: ${error.message}", Toast.LENGTH_SHORT).show()
                    // Navigate with default name if database error
                    navigateToMainDeck("User", email)
                }
            })
    }

    private fun signInWithGoogle() {
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false) // Set to false to show all accounts
            .setServerClientId(getString(R.string.default_web_client_id))
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        lifecycleScope.launch {
            try {
                val result = credentialManager.getCredential(
                    request = request,
                    context = this@MainActivity,
                )
                handleSignIn(result)
            } catch (e: GetCredentialException) {
                Log.e("MainActivity", "Google Sign-In failed", e)
                Toast.makeText(this@MainActivity, "Google Sign-In failed: ${e.message}",
                    Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun handleSignIn(result: GetCredentialResponse) {
        when (val credential = result.credential) {
            is GoogleIdTokenCredential -> {
                val googleIdToken = credential.idToken
                Log.d("MainActivity", "Received Google ID Token: $googleIdToken")

                // Sign in to Firebase with Google credential
                val firebaseCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                auth.signInWithCredential(firebaseCredential)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            Log.d("MainActivity", "signInWithCredential:success")
                            val user = auth.currentUser

                            // Store Google user in Realtime Database and get name from database
                            storeAndRetrieveGoogleUser(user?.displayName, user?.email)
                        } else {
                            Log.w("MainActivity", "signInWithCredential:failure", task.exception)
                            Toast.makeText(this, "Firebase authentication failed: ${task.exception?.message}",
                                Toast.LENGTH_SHORT).show()
                        }
                    }
            }
            else -> {
                Log.e("MainActivity", "Unexpected type of credential")
                Toast.makeText(this, "Unexpected credential type", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun storeAndRetrieveGoogleUser(googleDisplayName: String?, email: String?) {
        if (email != null) {
            // First, check if user already exists in database
            database.child("users").orderByChild("email").equalTo(email)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.exists()) {
                            // User exists, get their stored name
                            for (userSnapshot in snapshot.children) {
                                val storedName = userSnapshot.child("name").getValue(String::class.java)

                                // Update last login time
                                userSnapshot.ref.child("lastLogin").setValue(System.currentTimeMillis())

                                // Use stored name from database, fallback to Google display name
                                val finalName = storedName ?: googleDisplayName ?: "Google User"

                                // Toast confirmation for existing Google user
                                Toast.makeText(this@MainActivity, "Welcome back, $finalName!", Toast.LENGTH_SHORT).show()

                                navigateToMainDeck(finalName, email)
                                return
                            }
                        } else {
                            // User doesn't exist, create new user with Google info
                            val userId = email.replace(".", "_") // Firebase keys can't contain periods
                            val user = mapOf(
                                "name" to (googleDisplayName ?: "Google User"),
                                "email" to email,
                                "loginMethod" to "google",
                                "lastLogin" to System.currentTimeMillis()
                            )

                            database.child("users").child(userId).setValue(user)
                                .addOnSuccessListener {
                                    Log.d("MainActivity", "New Google user stored in database")
                                    val newUserName = googleDisplayName ?: "Google User"

                                    // Toast confirmation for new Google user creation
                                    Toast.makeText(this@MainActivity, "New account created for: $newUserName", Toast.LENGTH_SHORT).show()

                                    navigateToMainDeck(newUserName, email)
                                }
                                .addOnFailureListener { e ->
                                    Log.e("MainActivity", "Failed to store Google user: ${e.message}")
                                    val fallbackName = googleDisplayName ?: "Google User"

                                    // Toast for database storage failure
                                    Toast.makeText(this@MainActivity, "Database error, continuing as: $fallbackName", Toast.LENGTH_SHORT).show()

                                    // Navigate anyway with Google display name
                                    navigateToMainDeck(fallbackName, email)
                                }
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Log.e("MainActivity", "Database error during Google sign-in: ${error.message}")
                        val fallbackName = googleDisplayName ?: "Google User"

                        // Toast for database error during Google sign-in
                        Toast.makeText(this@MainActivity, "Database error, continuing as: $fallbackName", Toast.LENGTH_SHORT).show()

                        // Navigate with Google display name as fallback
                        navigateToMainDeck(fallbackName, email)
                    }
                })
        }
    }

    private fun navigateToMainDeck(name: String, email: String) {
        // Debug toast to confirm what's being passed
        Toast.makeText(this, "Navigating with Name: '$name', Email: '$email'", Toast.LENGTH_LONG).show()

        Log.d("MainActivity", "navigateToMainDeck called with name: '$name', email: '$email'")

        val intent = Intent(this, MainDeck::class.java)
        intent.putExtra("name_key", name)
        intent.putExtra("email_key", email)
        startActivity(intent)
        finish()
    }

    override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly
        val currentUser = auth.currentUser
        if (currentUser != null) {
            val userEmail = currentUser.email
            if (userEmail != null && userEmail.isNotEmpty()) {
                // Toast for auto-login attempt
                Toast.makeText(this, "Auto-login detected for: $userEmail", Toast.LENGTH_SHORT).show()

                // Get user name from database for auto-login
                getUserNameFromDatabase(userEmail)
            } else {
                // Handle case where Firebase user has no email
                Toast.makeText(this, "Auto-login failed: No email found", Toast.LENGTH_SHORT).show()
                Log.e("MainActivity", "Current user has no email address")
            }
        }
    }
}