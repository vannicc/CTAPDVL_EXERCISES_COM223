package com.example.instagramclone

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

class HomeFragment : Fragment() {
    private var email: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Retrieve the email from arguments
        arguments?.let {
            email = it.getString("email_key")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Find the textViewUsername and set it to the email
        val usernameTextView: TextView = view.findViewById(R.id.textViewUsername)
        usernameTextView.text = email ?: "Username"

        // You can also set the post username if needed
        val postUsernameTextView: TextView = view.findViewById(R.id.textViewPostUsername)
        postUsernameTextView.text = email ?: "Username"
    }

    companion object {
        @JvmStatic
        fun newInstance(email: String) =
            HomeFragment().apply {
                arguments = Bundle().apply {
                    putString("email_key", email)
                }
            }
    }
}