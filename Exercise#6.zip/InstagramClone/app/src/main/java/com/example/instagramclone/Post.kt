// Post.kt
package com.example.instagramclone

data class Post(
    val presidentId: PresidentId,
    val presidentName: String,
    val presidentTitle: String,
    val portraitResId: Int,
    val likesCount: Int = (1000..50000).random(),
    val commentsCount: Int = (100..2000).random(),
    val daysAgo: Int = (1..14).random(),
    val caption: String = "Official portrait of the President of the United States"
)