// PresidentId.kt
package com.example.instagramclone

enum class PresidentId {
    FORD,
    CARTER,
    REAGAN,
    BUSH1,
    CLINTON,
    BUSH2,
    OBAMA,
    TRUMP1,
    BIDEN,
    TRUMP2
}