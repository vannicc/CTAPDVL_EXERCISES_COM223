// PostAdapter.kt
package com.example.instagramclone

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PostAdapter(
    private val posts: List<Post>,
    private val currentUserEmail: String?
) : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    class PostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val profilePhoto: ImageView = itemView.findViewById(R.id.imageViewProfilePhoto)
        val username: TextView = itemView.findViewById(R.id.textViewUsername)
        val postImage: ImageView = itemView.findViewById(R.id.imageViewPost)
        val likeButton: ImageView = itemView.findViewById(R.id.imageViewLike)
        val commentButton: ImageView = itemView.findViewById(R.id.imageViewComment)
        val messageButton: ImageView = itemView.findViewById(R.id.imageViewMesssage)
        val bookmarkButton: ImageView = itemView.findViewById(R.id.imageViewBookmark)
        val totalViews: TextView = itemView.findViewById(R.id.textViewTotalViews)
        val postUsername: TextView = itemView.findViewById(R.id.textViewPostUsername)
        val caption: TextView = itemView.findViewById(R.id.textVIewCaption)
        val totalComments: TextView = itemView.findViewById(R.id.textViewTotalComments)
        val postedDays: TextView = itemView.findViewById(R.id.textViewPostedDays)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycler_home, parent, false)
        return PostViewHolder(itemView)
    }

    override fun getItemCount(): Int = posts.size

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = posts[position]

        // Set the profile image and post image
        holder.profilePhoto.setImageResource(post.portraitResId)
        holder.postImage.setImageResource(post.portraitResId)

        // Set username (either the president's name or the current user's email)
        holder.username.text = post.presidentName

        // Set views count (random number for demonstration)
        holder.totalViews.text = "${post.likesCount} views"

        // Set post username
        holder.postUsername.text = post.presidentName

        // Set post caption
        holder.caption.text = post.caption

        // Set comments
        holder.totalComments.text = "View all ${post.commentsCount} comments"

        // Set posted days
        holder.postedDays.text = "${post.daysAgo} days ago"

        // Set click listeners for the interaction buttons
        holder.likeButton.setOnClickListener {
            // Toggle between liked and not liked
            val newDrawable = if (holder.likeButton.tag == "liked") {
                holder.likeButton.tag = "not_liked"
                R.drawable.likes_unclicked
            } else {
                holder.likeButton.tag = "liked"
                R.drawable.post_liked
            }
            holder.likeButton.setImageResource(newDrawable)
        }

        holder.bookmarkButton.setOnClickListener {
            // Toggle between bookmarked and not bookmarked
            val newDrawable = if (holder.bookmarkButton.tag == "bookmarked") {
                holder.bookmarkButton.tag = "not_bookmarked"
                R.drawable.bookmark_unclicked
            } else {
                holder.bookmarkButton.tag = "bookmarked"
                R.drawable.bookmark_clicked
            }
            holder.bookmarkButton.setImageResource(newDrawable)
        }

        // Initialize the button states
        holder.likeButton.tag = "liked"
        holder.bookmarkButton.tag = "bookmarked"
    }
}