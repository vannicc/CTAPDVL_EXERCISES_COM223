package com.example.instagramclone

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment

class ProfileFragment : Fragment() {
    private var email: String? = null

    private lateinit var imageViewAddPostNow: ImageView
    private lateinit var imageViewProfileSettings: ImageView
    private lateinit var imageViewPosts: ImageView
    private lateinit var textViewEditProfile: TextView
    private lateinit var imageViewUserProfile: ImageView
    private lateinit var imageViewPostsGrid: ImageView
    private lateinit var imageViewPostsReels: ImageView
    private lateinit var imageViewTaggedPosts: ImageView

    // Request codes for image selection
    private val PICK_POST_IMAGE_REQUEST = 1
    private val PICK_PROFILE_IMAGE_REQUEST = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Retrieve the email from arguments
        arguments?.let {
            email = it.getString("email_key")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Find the relevant TextViews and set them to the email
        val loggedUserTextView: TextView = view.findViewById(R.id.textViewLoggedUser)
        loggedUserTextView.text = email ?: "Username"

        val profileNameTextView: TextView = view.findViewById(R.id.textViewUserProfileName)
        profileNameTextView.text = email ?: "Username"

        // Initialize views
        imageViewAddPostNow = view.findViewById(R.id.imageViewAddPostNow)
        imageViewProfileSettings = view.findViewById(R.id.imageViewProfileSettings)
        imageViewPosts = view.findViewById(R.id.imageViewPosts)
        textViewEditProfile = view.findViewById(R.id.textViewEditProfile)
        imageViewUserProfile = view.findViewById(R.id.imageViewUserProfile)
        imageViewPostsGrid = view.findViewById(R.id.imageViewPostsGrid)
        imageViewPostsReels = view.findViewById(R.id.imageViewPostsReels)
        imageViewTaggedPosts = view.findViewById(R.id.imageViewTaggedPosts)

        // Set click listener for imageViewAddPostNow
        imageViewAddPostNow.setOnClickListener {
            openGalleryForPost()
        }

        // Set click listener for textViewEditProfile to change profile picture
        textViewEditProfile.setOnClickListener {
            openGalleryForProfile()
        }

        // Set click listeners for grid views (optional functionality)
        imageViewPostsGrid.setOnClickListener {
            // Handle grid view click
        }

        imageViewPostsReels.setOnClickListener {
            // Handle reels view click
        }

        imageViewTaggedPosts.setOnClickListener {
            // Handle tagged posts view click
        }

        // Settings click listener
        imageViewProfileSettings.setOnClickListener {
            // Open settings or options menu
        }
    }

    // Function to open the gallery for post image
    private fun openGalleryForPost() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(intent, PICK_POST_IMAGE_REQUEST)
    }

    // Function to open the gallery for profile image
    private fun openGalleryForProfile() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(intent, PICK_PROFILE_IMAGE_REQUEST)
    }

    // Handle the result of the image selection
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            val imageUri: Uri = data.data!!

            when (requestCode) {
                PICK_PROFILE_IMAGE_REQUEST -> {
                    // Update imageViewUserProfile with the selected image
                    imageViewUserProfile.setImageURI(imageUri)
                }
                PICK_POST_IMAGE_REQUEST -> {
                    // Update imageViewPosts with the selected image
                    imageViewPosts.setImageURI(imageUri)
                }
            }
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(email: String) =
            ProfileFragment().apply {
                arguments = Bundle().apply {
                    putString("email_key", email)
                }
            }
    }
}